export const gamesList = [
  "BGMI",
  "Call of Duty: Mobile",
  "Free Fire",
  "Apex Legends Mobile",
  "Genshin Impact",
  // ... (rest of the games list)
  "Greedfall",
  "FIFA",
]

